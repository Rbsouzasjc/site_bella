# 💅 Beauty Salon — Landing Page 3D Vibrante

## 📋 Sobre o Projeto
Landing Page de alta conversão para Salão de Beleza de luxo com design **vibrante e 3D**. Paleta com **Rosa Vivo + Verde Menta intenso**, gradientes dinâmicos e efeitos tridimensionais marcantes em cards, botões e imagens.

## ✅ Funcionalidades Implementadas

### Seções da Landing Page
1. **Header Fixo** — Logo com gradiente, menu com link ativo gradiente, botão CTA 3D
2. **Hero Section** — Layout dividido, imagem com perspective 3D, orbs flutuantes animados, stats em cards 3D
3. **Por que nos escolher** — 3 cards 3D com ícones alternando verde/rosa/gradiente
4. **Serviços (Grid)** — 4 cards com sombra 3D, ícones alternando gradiente verde↔rosa
5. **Equipe** — Fotos com borda gradiente (verde→rosa), cards com tilt 3D
6. **Portfólio** — Galeria com overlay gradiente e hover 3D
7. **Depoimentos** — Cards com barra superior colorida (verde/rosa/gradiente), aspas gradiente
8. **Formulário de Agendamento** — Glassmorphism com backdrop-blur, inputs com glow no focus
9. **Footer** — Barra gradiente no topo, ícones sociais com hover gradiente

### Efeitos 3D Implementados
- ✅ **Tilt 3D interativo** — Cards seguem o mouse com `perspective(800px)` + `rotateX/Y`
- ✅ **Botões 3D** — `box-shadow` com "base" sólida simulando profundidade + feedback `:active`
- ✅ **Imagem Hero 3D** — `rotateY(-3deg) rotateX(2deg)` com hover retornando ao plano
- ✅ **Cards com sombra 3D** — Multi-camada `box-shadow` com inset highlight branco
- ✅ **Floating badges 3D** — Animação com `rotateZ` sutil
- ✅ **Orbs animados** — Gradientes radiais com `scale` + `translate` em loop
- ✅ **Hover lift** — `translateY(-12px) scale(1.02)` com sombra expandida

### Paleta de Cores (v2 — Vibrante)
| Elemento | Cor | Hex |
|----------|-----|-----|
| Verde Vivo | Principal | `#2EC4A5` |
| Verde Escuro | Hover | `#0FA881` |
| Rosa Vivo | Destaque | `#F4508E` |
| Rosa Claro | Hover | `#FF7EB3` |
| Gradiente | Verde → Rosa | `135deg, #2EC4A5 → #F4508E` |
| Texto | Charcoal | `#1A1A2E` |

### Funcionalidades Técnicas
- ✅ **Botão WhatsApp 3D** com pulso + gradiente verde
- ✅ **Menu Hambúrguer** com overlay blur
- ✅ **Scroll Spy** com link ativo em gradiente
- ✅ **Scroll Reveal** com fade-up stagger
- ✅ **Máscara WhatsApp** — (00) 00000-0000
- ✅ **Formulário → WhatsApp** API
- ✅ **100% Responsivo** — Mobile-first

## 📁 Estrutura

```
/
├── index.html     ← Arquivo único (HTML + CSS + JS)
└── README.md      ← Documentação
```

## 🔗 URIs de Entrada

| Caminho | Descrição |
|---------|-----------|
| `/` | Landing Page completa |
| `/#servicos` | Serviços |
| `/#equipe` | Equipe |
| `/#portfolio` | Portfólio |
| `/#depoimentos` | Depoimentos |
| `/#agendamento` | Formulário |

## 🚀 Como Usar
1. Salve `index.html`
2. Abra no navegador ou publique na aba **Publish**

## ⏭️ Próximos Passos
- [ ] Substituir imagens por fotos reais do salão
- [ ] Configurar número real do WhatsApp (`5511999990000`)
- [ ] Adicionar Google Maps no footer
- [ ] Integrar Google Analytics / Meta Pixel
